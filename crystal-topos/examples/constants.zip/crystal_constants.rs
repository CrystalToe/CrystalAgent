// Copyright (c) 2026 Daland Montgomery
// SPDX-License-Identifier: AGPL-3.0-or-later
//
// crystal_constants.rs — Universal physics constants from two primes
//
// Every constant derives from NW=2, NC=3 via the spectral action on
// A_F = C + M2(C) + M3(C). Zero free parameters.
//
// Bevy: add as module. use crystal_constants::*;
// Custom: copy file, no dependencies.

#![allow(dead_code)]

// ── Crystal atoms ──
pub const NW: u32 = 2;
pub const NC: u32 = 3;
pub const D1: u32 = 1;
pub const D2: u32 = NC;                            // 3
pub const D3: u32 = NC * NC - 1;                   // 8
pub const D4: u32 = NW * NW * NW * NC;             // 24
pub const CHI: u32 = NW * NC;                      // 6
pub const BETA0: u32 = (11 * NC - 2 * CHI) / 3;   // 7
pub const SIGMA_D: u32 = D1 + D2 + D3 + D4;       // 36
pub const SIGMA_D2: u32 = D1*D1 + D2*D2 + D3*D3 + D4*D4; // 650
pub const GAUSS: u32 = NC * NC + NW * NW;          // 13
pub const D_TOTAL: u32 = SIGMA_D + CHI;            // 42

// ── Optics (PBR) ──
pub const IOR_WATER: f64   = (NC * NC - 1) as f64 / (2 * NC) as f64;   // 4/3
pub const IOR_GLASS: f64   = NC as f64 / NW as f64;                     // 3/2
pub const IOR_DIAMOND: f64 = 29.0 / 12.0;                               // 29/12

// ── Scattering & radiation ──
pub const PLANCK_LAMBDA_EXP: u32   = CHI - 1;       // 5
pub const RAYLEIGH_SIZE_EXP: u32   = CHI;            // 6
pub const RAYLEIGH_LAMBDA_EXP: u32 = NW * NW;        // 4
pub const STEFAN_T_EXP: u32  = NW * NW;              // 4
pub const STEFAN_DENOM: u32  = NC * (CHI - 1);       // 15

// ── Thermodynamics ──
pub const GAMMA_DIATOMIC: f64  = BETA0 as f64 / (CHI - 1) as f64;  // 7/5
pub const GAMMA_MONATOMIC: f64 = (CHI - 1) as f64 / NC as f64;     // 5/3

// ── Fluid dynamics ──
pub const KARMAN: f64         = NW as f64 / (CHI - 1) as f64;      // 2/5
pub const KOLMOGOROV_EXP: f64 = -((CHI - 1) as f64) / NC as f64;   // -5/3
pub const STOKES_DRAG: u32    = D4;                                   // 24
pub const BLASIUS: f64        = 1.0 / (NW * NW) as f64;              // 1/4

// ── Mechanics ──
pub const POISSON_INCOMPRESSIBLE: f64 = 0.5;                          // T_F
pub const POISSON_METAL: f64          = NC as f64 / (GAUSS - NC) as f64; // 3/10
pub const POISSON_ALUMINUM: f64       = 1.0 / NC as f64;              // 1/3
pub const POISSON_CONCRETE: f64       = 1.0 / (CHI - 1) as f64;     // 1/5

// ── Blast / scaling ──
pub const SEDOV_TAYLOR: f64 = NW as f64 / (CHI - 1) as f64;         // 2/5 = Flory

// ── Audio ──
pub const SABINE_INTEGER: u32 = D4;                  // 24
pub const OCTAVE_RATIO: u32   = NW;                  // 2
pub const FIFTH_RATIO: f64    = NC as f64 / NW as f64;              // 3/2
pub const FOURTH_RATIO: f64   = (NC * NC - 1) as f64 / (2 * NC) as f64; // 4/3

// ── Procedural ──
pub const HURST_BROWNIAN: f64 = 0.5;                 // T_F
pub const FBM_LACUNARITY: u32 = NW;                   // 2
pub const NYQUIST_FACTOR: u32 = NW;                   // 2

#[cfg(test)]
mod tests {
    use super::*;

    fn approx(a: f64, b: f64) -> bool { (a - b).abs() < 1e-10 }

    #[test] fn ior_water()   { assert!(approx(IOR_WATER, 4.0/3.0)); }
    #[test] fn ior_glass()   { assert!(approx(IOR_GLASS, 1.5)); }
    #[test] fn gamma_dia()   { assert!(approx(GAMMA_DIATOMIC, 1.4)); }
    #[test] fn gamma_mono()  { assert!(approx(GAMMA_MONATOMIC, 5.0/3.0)); }
    #[test] fn karman()      { assert!(approx(KARMAN, 0.4)); }
    #[test] fn kolmogorov()  { assert!(approx(KOLMOGOROV_EXP, -5.0/3.0)); }
    #[test] fn stokes()      { assert_eq!(STOKES_DRAG, 24); }
    #[test] fn planck()      { assert_eq!(PLANCK_LAMBDA_EXP, 5); }
    #[test] fn rayleigh_d()  { assert_eq!(RAYLEIGH_SIZE_EXP, 6); }
    #[test] fn rayleigh_l()  { assert_eq!(RAYLEIGH_LAMBDA_EXP, 4); }
    #[test] fn poisson_inc() { assert!(approx(POISSON_INCOMPRESSIBLE, 0.5)); }
    #[test] fn sedov()       { assert!(approx(SEDOV_TAYLOR, 0.4)); }
}
