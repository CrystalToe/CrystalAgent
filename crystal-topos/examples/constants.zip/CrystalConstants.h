// Copyright (c) 2026 Daland Montgomery
// SPDX-License-Identifier: AGPL-3.0-or-later
//
// CrystalConstants.h — Universal physics constants from two primes
//
// Every constant derives from NW=2, NC=3 via the spectral action on
// A_F = C + M2(C) + M3(C). Zero free parameters.
//
// Unreal: add to Source/YourProject/. #include "CrystalConstants.h"
// Custom: header-only, no dependencies.

#pragma once

namespace Crystal {

// ── Crystal atoms ──
constexpr int NW = 2;
constexpr int NC = 3;
constexpr int D1 = 1;
constexpr int D2 = NC;                           // 3
constexpr int D3 = NC * NC - 1;                  // 8
constexpr int D4 = NW * NW * NW * NC;            // 24
constexpr int CHI = NW * NC;                     // 6
constexpr int BETA0 = (11 * NC - 2 * CHI) / 3;  // 7
constexpr int SIGMA_D = D1 + D2 + D3 + D4;      // 36
constexpr int SIGMA_D2 = D1*D1 + D2*D2 + D3*D3 + D4*D4; // 650
constexpr int GAUSS = NC * NC + NW * NW;         // 13
constexpr int D_TOTAL = SIGMA_D + CHI;           // 42

// ── Optics (PBR) ──
constexpr double IOR_WATER   = static_cast<double>(NC * NC - 1) / (2.0 * NC);  // 4/3
constexpr double IOR_GLASS   = static_cast<double>(NC) / NW;                    // 3/2
constexpr double IOR_DIAMOND = 29.0 / 12.0;                                     // 29/12

constexpr double Sq(double x) { return x * x; }

constexpr double F0_WATER   = Sq((IOR_WATER - 1.0) / (IOR_WATER + 1.0));    // 1/49
constexpr double F0_GLASS   = Sq((IOR_GLASS - 1.0) / (IOR_GLASS + 1.0));    // 1/25
constexpr double F0_DIAMOND = Sq((IOR_DIAMOND - 1.0) / (IOR_DIAMOND + 1.0));

// ── Scattering & radiation ──
constexpr int PLANCK_LAMBDA_EXP   = CHI - 1;        // 5
constexpr int RAYLEIGH_SIZE_EXP   = CHI;             // 6
constexpr int RAYLEIGH_LAMBDA_EXP = NW * NW;         // 4
constexpr int STEFAN_T_EXP        = NW * NW;         // 4
constexpr int STEFAN_DENOM        = NC * (CHI - 1);  // 15

// ── Thermodynamics ──
constexpr double GAMMA_DIATOMIC  = static_cast<double>(BETA0) / (CHI - 1);  // 7/5
constexpr double GAMMA_MONATOMIC = static_cast<double>(CHI - 1) / NC;       // 5/3

// ── Fluid dynamics ──
constexpr double KARMAN         = static_cast<double>(NW) / (CHI - 1);      // 2/5
constexpr double KOLMOGOROV_EXP = -static_cast<double>(CHI - 1) / NC;       // -5/3
constexpr int    STOKES_DRAG    = D4;                                         // 24
constexpr double BLASIUS        = 1.0 / (NW * NW);                           // 1/4

// ── Mechanics ──
constexpr double POISSON_INCOMPRESSIBLE = 0.5;                                // T_F
constexpr double POISSON_METAL          = static_cast<double>(NC) / (GAUSS - NC); // 3/10
constexpr double POISSON_ALUMINUM       = 1.0 / NC;                           // 1/3
constexpr double POISSON_CONCRETE       = 1.0 / (CHI - 1);                   // 1/5

// ── Blast / scaling ──
constexpr double SEDOV_TAYLOR = static_cast<double>(NW) / (CHI - 1);         // 2/5 = Flory

// ── Audio ──
constexpr int    SABINE_INTEGER = D4;                 // 24
constexpr int    OCTAVE_RATIO   = NW;                 // 2
constexpr double FIFTH_RATIO    = static_cast<double>(NC) / NW;              // 3/2
constexpr double FOURTH_RATIO   = static_cast<double>(NC * NC - 1) / (2.0 * NC); // 4/3

// ── Procedural ──
constexpr double HURST_BROWNIAN = 0.5;                // T_F
constexpr int    FBM_LACUNARITY = NW;                  // 2
constexpr int    NYQUIST_FACTOR = NW;                  // 2

} // namespace Crystal
