# Copyright (c) 2026 Daland Montgomery
# SPDX-License-Identifier: AGPL-3.0-or-later
#
# crystal_constants.gd — Universal physics constants from two primes
#
# Every constant derives from NW=2, NC=3 via the spectral action on
# A_F = C + M2(C) + M3(C). Zero free parameters.
#
# Godot: drop into res://scripts/. Access via CrystalConstants.IOR_WATER etc.

class_name CrystalConstants

# ── Crystal atoms ──
const NW: int = 2
const NC: int = 3
const D1: int = 1
const D2: int = NC                          # 3
const D3: int = NC * NC - 1                 # 8
const D4: int = NW * NW * NW * NC           # 24
const CHI: int = NW * NC                    # 6
const BETA0: int = (11 * NC - 2 * CHI) / 3 # 7
const SIGMA_D: int = D1 + D2 + D3 + D4     # 36
const GAUSS: int = NC * NC + NW * NW        # 13
const D_TOTAL: int = SIGMA_D + CHI          # 42

# ── Optics (PBR) ──
const IOR_WATER: float   = float(NC * NC - 1) / float(2 * NC)  # 4/3
const IOR_GLASS: float   = float(NC) / float(NW)               # 3/2
const IOR_DIAMOND: float = 29.0 / 12.0                         # 29/12

# ── Scattering & radiation ──
const PLANCK_LAMBDA_EXP: int   = CHI - 1     # 5
const RAYLEIGH_SIZE_EXP: int   = CHI          # 6
const RAYLEIGH_LAMBDA_EXP: int = NW * NW      # 4
const STEFAN_T_EXP: int  = NW * NW            # 4

# ── Thermodynamics ──
const GAMMA_DIATOMIC: float  = float(BETA0) / float(CHI - 1) # 7/5
const GAMMA_MONATOMIC: float = float(CHI - 1) / float(NC)    # 5/3

# ── Fluid dynamics ──
const KARMAN: float         = float(NW) / float(CHI - 1)     # 2/5
const KOLMOGOROV_EXP: float = -float(CHI - 1) / float(NC)    # -5/3
const STOKES_DRAG: int      = D4                               # 24
const BLASIUS: float        = 1.0 / float(NW * NW)            # 1/4

# ── Mechanics ──
const POISSON_INCOMPRESSIBLE: float = 0.5                      # T_F
const POISSON_METAL: float    = float(NC) / float(GAUSS - NC) # 3/10
const POISSON_ALUMINUM: float = 1.0 / float(NC)               # 1/3
const POISSON_CONCRETE: float = 1.0 / float(CHI - 1)          # 1/5

# ── Blast / scaling ──
const SEDOV_TAYLOR: float = float(NW) / float(CHI - 1)        # 2/5 = Flory

# ── Audio ──
const SABINE_INTEGER: int = D4                                  # 24
const OCTAVE_RATIO: int   = NW                                  # 2
const FIFTH_RATIO: float  = float(NC) / float(NW)             # 3/2
const FOURTH_RATIO: float = float(NC * NC - 1) / float(2 * NC) # 4/3

# ── Procedural ──
const HURST_BROWNIAN: float = 0.5                               # T_F
const FBM_LACUNARITY: int   = NW                                # 2
const NYQUIST_FACTOR: int   = NW                                # 2
