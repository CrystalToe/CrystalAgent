# Copyright (c) 2026 Daland Montgomery
# SPDX-License-Identifier: AGPL-3.0-or-later
#
# crystal_blender.py — Blender addon: crystal-derived physics constants
#
# Install: Edit > Preferences > Add-ons > Install > select this file
# Usage:   3D Viewport sidebar > Crystal Topos panel
#
# Every constant derives from N_W=2, N_C=3. Zero free parameters.
# Applies to: Cycles/EEVEE materials, Mantaflow smoke/fire, particle systems.

bl_info = {
    "name": "Crystal Topos Physics",
    "blender": (4, 0, 0),
    "category": "Physics",
    "version": (1, 0, 0),
    "author": "Daland Montgomery",
    "description": "Crystal-derived physics constants from two primes",
    "doc_url": "https://github.com/CrystalToe/CrystalAgent",
}

import bpy
import math

# ═══════════════════════════════════════════════════════════════════
# CRYSTAL ATOMS — from A_F = C + M2(C) + M3(C)
# ═══════════════════════════════════════════════════════════════════

N_W, N_C = 2, 3
CHI     = N_W * N_C                          # 6
BETA0   = (11 * N_C - 2 * CHI) // 3         # 7
SIGMA_D = 1 + N_C + (N_C**2 - 1) + (N_W**3 * N_C)  # 36
GAUSS   = N_C**2 + N_W**2                   # 13
D4      = N_W**3 * N_C                      # 24

# ═══════════════════════════════════════════════════════════════════
# DERIVED CONSTANTS
# ═══════════════════════════════════════════════════════════════════

# Optics
IOR_WATER   = (N_C**2 - 1) / (2 * N_C)      # 4/3
IOR_GLASS   = N_C / N_W                      # 3/2
IOR_DIAMOND = 29 / 12                        # 29/12

F0_WATER   = ((IOR_WATER - 1) / (IOR_WATER + 1))**2    # 1/49
F0_GLASS   = ((IOR_GLASS - 1) / (IOR_GLASS + 1))**2    # 1/25
F0_DIAMOND = ((IOR_DIAMOND - 1) / (IOR_DIAMOND + 1))**2

# Thermodynamics
GAMMA_DIATOMIC  = BETA0 / (CHI - 1)         # 7/5
GAMMA_MONATOMIC = (CHI - 1) / N_C           # 5/3

# Fluid
KARMAN         = N_W / (CHI - 1)             # 2/5
KOLMOGOROV_EXP = -(CHI - 1) / N_C           # -5/3
STOKES_DRAG    = D4                          # 24
BLASIUS        = 1 / N_W**2                  # 1/4

# Mechanics
POISSON_INCOMP   = 1 / N_W                  # 1/2
POISSON_METAL    = N_C / (GAUSS - N_C)      # 3/10
POISSON_CONCRETE = 1 / (CHI - 1)            # 1/5

# Scattering
PLANCK_EXP       = CHI - 1                   # 5
RAYLEIGH_SIZE    = CHI                       # 6
RAYLEIGH_LAMBDA  = N_W**2                    # 4

# Blast
SEDOV_TAYLOR = N_W / (CHI - 1)              # 2/5

# ═══════════════════════════════════════════════════════════════════
# MATERIAL PRESETS
# ═══════════════════════════════════════════════════════════════════

MATERIALS = {
    "Crystal Water": {
        "ior": IOR_WATER,
        "roughness": 0.0,
        "transmission": 1.0,
        "color": (0.8, 0.9, 1.0, 1.0),
    },
    "Crystal Glass": {
        "ior": IOR_GLASS,
        "roughness": 0.0,
        "transmission": 1.0,
        "color": (1.0, 1.0, 1.0, 1.0),
    },
    "Crystal Diamond": {
        "ior": IOR_DIAMOND,
        "roughness": 0.0,
        "transmission": 1.0,
        "color": (1.0, 1.0, 1.0, 1.0),
    },
}

# ═══════════════════════════════════════════════════════════════════
# OPERATORS
# ═══════════════════════════════════════════════════════════════════

class CRYSTAL_OT_apply_material(bpy.types.Operator):
    """Apply a crystal-derived material to the active object"""
    bl_idname = "crystal.apply_material"
    bl_label = "Apply Crystal Material"
    bl_options = {'REGISTER', 'UNDO'}

    material_name: bpy.props.StringProperty(name="Material")

    def execute(self, context):
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            self.report({'WARNING'}, "Select a mesh object")
            return {'CANCELLED'}

        preset = MATERIALS.get(self.material_name)
        if preset is None:
            self.report({'WARNING'}, f"Unknown material: {self.material_name}")
            return {'CANCELLED'}

        mat = bpy.data.materials.get(self.material_name)
        if mat is None:
            mat = bpy.data.materials.new(name=self.material_name)
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        nodes.clear()

        output = nodes.new('ShaderNodeOutputMaterial')
        bsdf = nodes.new('ShaderNodeBsdfPrincipled')
        bsdf.location = (-300, 0)
        mat.node_tree.links.new(bsdf.outputs['BSDF'], output.inputs['Surface'])

        bsdf.inputs['IOR'].default_value = preset["ior"]
        bsdf.inputs['Roughness'].default_value = preset["roughness"]
        bsdf.inputs['Transmission Weight'].default_value = preset["transmission"]
        bsdf.inputs['Base Color'].default_value = preset["color"]

        if obj.data.materials:
            obj.data.materials[0] = mat
        else:
            obj.data.materials.append(mat)

        self.report({'INFO'}, f"Applied {self.material_name} (IOR={preset['ior']:.4f})")
        return {'FINISHED'}


class CRYSTAL_OT_print_constants(bpy.types.Operator):
    """Print all crystal-derived constants to the console"""
    bl_idname = "crystal.print_constants"
    bl_label = "Print Constants"

    def execute(self, context):
        print("\n=== Crystal Topos Constants (from N_W=2, N_C=3) ===")
        print(f"  IOR water:   {IOR_WATER:.6f}  (4/3)")
        print(f"  IOR glass:   {IOR_GLASS:.6f}  (3/2)")
        print(f"  IOR diamond: {IOR_DIAMOND:.6f}  (29/12)")
        print(f"  F0 water:    {F0_WATER:.6f}  (1/49)")
        print(f"  F0 glass:    {F0_GLASS:.6f}  (1/25)")
        print(f"  gamma(air):  {GAMMA_DIATOMIC:.6f}  (7/5)")
        print(f"  gamma(He):   {GAMMA_MONATOMIC:.6f}  (5/3)")
        print(f"  von Karman:  {KARMAN:.6f}  (2/5)")
        print(f"  Kolmogorov:  {KOLMOGOROV_EXP:.6f}  (-5/3)")
        print(f"  Stokes C_d:  {STOKES_DRAG}  (24)")
        print(f"  Blasius:     {BLASIUS:.6f}  (1/4)")
        print(f"  Planck exp:  {PLANCK_EXP}  (chi-1=5)")
        print(f"  Rayleigh d:  {RAYLEIGH_SIZE}  (chi=6)")
        print(f"  Rayleigh l:  {RAYLEIGH_LAMBDA}  (N_w^2=4)")
        print(f"  Poisson(inc):{POISSON_INCOMP:.6f}  (1/2)")
        print(f"  Poisson(Fe): {POISSON_METAL:.6f}  (3/10)")
        print(f"  Sedov-Taylor:{SEDOV_TAYLOR:.6f}  (2/5)")
        self.report({'INFO'}, "Constants printed to console")
        return {'FINISHED'}

# ═══════════════════════════════════════════════════════════════════
# UI PANEL
# ═══════════════════════════════════════════════════════════════════

class CRYSTAL_PT_panel(bpy.types.Panel):
    """Crystal Topos Physics Constants"""
    bl_label = "Crystal Topos"
    bl_idname = "CRYSTAL_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Crystal"

    def draw(self, context):
        layout = self.layout

        layout.label(text="Materials (crystal-derived IOR)")
        for name in MATERIALS:
            op = layout.operator("crystal.apply_material", text=name)
            op.material_name = name

        layout.separator()
        layout.label(text="Constants")
        col = layout.column(align=True)
        col.label(text=f"IOR water: {IOR_WATER:.4f} = 4/3")
        col.label(text=f"IOR glass: {IOR_GLASS:.4f} = 3/2")
        col.label(text=f"IOR diamond: {IOR_DIAMOND:.4f} = 29/12")
        col.label(text=f"gamma(air): {GAMMA_DIATOMIC:.4f} = 7/5")
        col.label(text=f"Kolmogorov: {KOLMOGOROV_EXP:.4f} = -5/3")
        col.label(text=f"Stokes: {STOKES_DRAG} = 24")
        col.label(text=f"Planck exp: {PLANCK_EXP} = chi-1")
        col.label(text=f"Rayleigh: d^{RAYLEIGH_SIZE}/lambda^{RAYLEIGH_LAMBDA}")

        layout.separator()
        layout.operator("crystal.print_constants", text="Print All to Console")

# ═══════════════════════════════════════════════════════════════════
# REGISTRATION
# ═══════════════════════════════════════════════════════════════════

classes = (
    CRYSTAL_OT_apply_material,
    CRYSTAL_OT_print_constants,
    CRYSTAL_PT_panel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
