// Copyright (c) 2026 Daland Montgomery
// SPDX-License-Identifier: AGPL-3.0-or-later
//
// CrystalConstants.cs — Universal physics constants from two primes
//
// Every constant derives from NW=2, NC=3 via the spectral action on
// A_F = C + M2(C) + M3(C). Zero free parameters.
//
// Unity: drop into Assets/Scripts/. Access via CrystalConstants.IOR_WATER etc.

using System;

public static class CrystalConstants
{
    // ── Crystal atoms ──
    public const int NW = 2;
    public const int NC = 3;
    public const int D1 = 1;
    public const int D2 = NC;                           // 3
    public const int D3 = NC * NC - 1;                  // 8
    public const int D4 = NW * NW * NW * NC;            // 24
    public const int CHI = NW * NC;                     // 6
    public const int BETA0 = (11 * NC - 2 * CHI) / 3;  // 7
    public const int SIGMA_D = D1 + D2 + D3 + D4;      // 36
    public const int SIGMA_D2 = D1*D1 + D2*D2 + D3*D3 + D4*D4; // 650
    public const int GAUSS = NC * NC + NW * NW;         // 13
    public const int D_TOTAL = SIGMA_D + CHI;           // 42

    // ── Optics (PBR) ──
    public const float IOR_WATER   = (NC * NC - 1f) / (2f * NC);  // 4/3
    public const float IOR_GLASS   = (float)NC / NW;               // 3/2
    public const float IOR_DIAMOND = 29f / 12f;                    // 29/12

    public static readonly float F0_WATER   = Sq((IOR_WATER - 1f) / (IOR_WATER + 1f));
    public static readonly float F0_GLASS   = Sq((IOR_GLASS - 1f) / (IOR_GLASS + 1f));
    public static readonly float F0_DIAMOND = Sq((IOR_DIAMOND - 1f) / (IOR_DIAMOND + 1f));

    // ── Scattering & radiation ──
    public const int PLANCK_LAMBDA_EXP    = CHI - 1;       // 5
    public const int RAYLEIGH_SIZE_EXP    = CHI;            // 6
    public const int RAYLEIGH_LAMBDA_EXP  = NW * NW;        // 4
    public const int STEFAN_T_EXP         = NW * NW;        // 4
    public const int STEFAN_DENOM         = NC * (CHI - 1); // 15

    // ── Thermodynamics ──
    public const float GAMMA_DIATOMIC  = (float)BETA0 / (CHI - 1);  // 7/5
    public const float GAMMA_MONATOMIC = (float)(CHI - 1) / NC;     // 5/3

    // ── Fluid dynamics ──
    public const float KARMAN         = (float)NW / (CHI - 1);      // 2/5
    public const float KOLMOGOROV_EXP = -(float)(CHI - 1) / NC;     // -5/3
    public const int   STOKES_DRAG    = D4;                          // 24
    public const float BLASIUS        = 1f / (NW * NW);              // 1/4

    // ── Mechanics ──
    public const float POISSON_INCOMPRESSIBLE = 0.5f;                // T_F
    public const float POISSON_METAL          = (float)NC / (GAUSS - NC); // 3/10
    public const float POISSON_ALUMINUM       = 1f / NC;             // 1/3
    public const float POISSON_CONCRETE       = 1f / (CHI - 1);     // 1/5

    // ── Blast / scaling ──
    public const float SEDOV_TAYLOR = (float)NW / (CHI - 1);        // 2/5 = Flory

    // ── Audio ──
    public const int SABINE_INTEGER = D4;                            // 24
    public const int OCTAVE_RATIO   = NW;                            // 2
    public const float FIFTH_RATIO  = (float)NC / NW;               // 3/2
    public const float FOURTH_RATIO = (NC * NC - 1f) / (2f * NC);   // 4/3

    // ── Procedural ──
    public const float HURST_BROWNIAN = 0.5f;                       // T_F
    public const int   FBM_LACUNARITY = NW;                          // 2
    public const int   NYQUIST_FACTOR = NW;                          // 2

    private static float Sq(float x) => x * x;
}
